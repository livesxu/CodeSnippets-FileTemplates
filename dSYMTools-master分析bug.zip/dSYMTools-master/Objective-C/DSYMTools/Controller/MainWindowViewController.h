//
//  MainWindowViewController.h
//  CustomModalWindow
//
//  Created by answer on 7/26/16.
//  Copyright © 2016 answer. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface MainWindowViewController : NSWindowController

@end
