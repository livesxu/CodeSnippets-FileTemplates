//
//  AppDelegate.h
//  DSYMTools
//
//  Created by answer on 7/25/16.
//  Copyright © 2016 answer. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

