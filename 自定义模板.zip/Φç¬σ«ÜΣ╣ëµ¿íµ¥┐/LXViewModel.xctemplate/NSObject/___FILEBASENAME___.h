//___FILEHEADER___

___IMPORTHEADER_cocoaSubclass___

@interface ___FILEBASENAMEASIDENTIFIER___ : ___VARIABLE_cocoaSubclass___

@end
