//___FILEHEADER___

___IMPORTHEADER_cocoaSubclass___

#import "<#modelClass#>.h"

@interface ___FILEBASENAMEASIDENTIFIER___ : ___VARIABLE_cocoaSubclass___
    
@property (nonatomic, strong) <#modelClass#> *model;

@end
