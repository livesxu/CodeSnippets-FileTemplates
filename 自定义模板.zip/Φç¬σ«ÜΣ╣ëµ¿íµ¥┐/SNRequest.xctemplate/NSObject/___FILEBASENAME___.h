//___FILEHEADER___

#import "SNBaseRequest.h"

typedef void(^RequestBlock)(BOOL isSuccess, NSString *errorMsg);

@interface ___FILEBASENAMEASIDENTIFIER___ : SNBaseRequest

@property (nonatomic, strong) NSMutableArray *dataArray;

/**
 布局数据
 
 @param layoutData 成功||失败
 */
- (void)layoutRequestBackData:(RequestBlock)layoutData;

@end
