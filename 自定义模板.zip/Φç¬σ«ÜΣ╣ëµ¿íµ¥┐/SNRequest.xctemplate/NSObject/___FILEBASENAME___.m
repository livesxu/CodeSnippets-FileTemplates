//___FILEHEADER___

#import "___FILEBASENAME___.h"

#import "SNMBLoginProtocal.h"
#import "SNContextProtocol.h"
#import "DataCenterInUserDefaultsProtocol.h"

@interface ___FILEBASENAMEASIDENTIFIER___ ()

@property (nonatomic, copy) RequestBlock completeBlock;

@end

@implementation ___FILEBASENAMEASIDENTIFIER___

- (NSString *)appClient
{
    return @"ios";
}

- (NSString *)appVersion
{
    return [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleShortVersionString"];
}

- (NSDictionary *)responseHeaders
{
    NSDictionary *dic = self.requestOperation.response.allHeaderFields;
    SNMB_LOGIN_GETUSERCENTER(userInfo)
    if (userInfo) {
        //如果已登录且header中有值则登录失效
        if (userInfo.isLogined) {
            NSString *loginFlag = nil;
            id temp = dic[@"passport.login.flag"];
            if ([temp isKindOfClass:[NSString class]])
            {
                loginFlag = temp;
            }
            else if ([temp isKindOfClass:[NSNumber class]])
            {
                loginFlag = [temp stringValue];
            }
            if (NotNilAndNull(loginFlag))
            {
                userInfo.isLogined = NO;
                SNMB_LOGIN_VIEWCTRL_OBJ(vc);
                SNGetContextModule(context);
                [context clearViewCtrlersWithCommplete:^{
                    [[context topNavigation] presentViewController:vc animated:YES completion:nil];
                }];
            }
            NSArray *tgcAry = [dic[@"Set-Cookie"] componentsSeparatedByString:@"TGC="];
            NSArray *loginTGCAry = [[tgcAry safeObjectAtIndex:1] componentsSeparatedByString:@";"];
            NSString *loginTGC = [loginTGCAry safeObjectAtIndex:0];
            SN_GLOBALDATA_GET_USER_DEFAULT_CENTER(dataCenter);
            if(!IsStrEmpty(loginTGC)){
                dataCenter.loginTGC=loginTGC;
            }
        }
    }
    return self.requestOperation.response.allHeaderFields;
}

- (NSMutableArray *)dataArray{
    if (!_dataArray) {
        
        _dataArray = [NSMutableArray array];
        
    }
    return _dataArray;
}

/**
 布局数据
 
 @param layoutData 成功||失败
 */
- (void)layoutRequestBackData:(RequestBlock)layoutData;{
    
    self.completeBlock = layoutData;
    [self start];
}

- (NSString *)requestUrl {
    return <#requestUrl#>;
}

- (SNRequestMethod)requestMethod {
    return <#SNRequestMethod#>;
}

- (void)requestDidCompleted {
    [super requestDidCompleted];
    NSDictionary *responseDic = self.responseJSONObject;
    BOOL isSuccess = [@"0" isEqualToString:[responseDic valueForKey:@"resultCode"]];
    
    if (isSuccess) {
        <#statements#>
    } else {
        <#statements#>
    }
}

- (void)requestDidFailed {
    [super requestDidFailed];
    if (self.completeBlock) {
        if (!self) {
            return;
        }
        self.completeBlock(NO,@"服务器开小差了，请您稍后再试");
    }
}


@end
