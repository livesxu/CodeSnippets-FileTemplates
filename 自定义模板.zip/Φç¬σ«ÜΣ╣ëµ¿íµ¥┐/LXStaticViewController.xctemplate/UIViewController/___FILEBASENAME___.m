//___FILEHEADER___

#import "___FILEBASENAME___.h"

@interface ___FILEBASENAMEASIDENTIFIER___ ()

@end

@implementation ___FILEBASENAMEASIDENTIFIER___

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do view setup here.
}

#pragma mark - 界面加载
- (void)staticViewsWithoutNib{
    
    self.title = <#titleString#>;
}

/**
 加载数据
 */
- (void)loadData;{
    
}
#pragma mark - Change Values


#pragma mark - Delegate


#pragma mark - Lazy load


@end
