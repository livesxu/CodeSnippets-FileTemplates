//___FILEHEADER___

#import "CommonViewController.h"

@interface ___FILEBASENAMEASIDENTIFIER___ : CommonViewController

@end
