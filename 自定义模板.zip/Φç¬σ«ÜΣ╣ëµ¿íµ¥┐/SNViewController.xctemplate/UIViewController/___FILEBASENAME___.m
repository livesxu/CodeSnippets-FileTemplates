//___FILEHEADER___

#import "___FILEBASENAME___.h"

#import "NSAddressNoDataView.h"

@interface ___FILEBASENAMEASIDENTIFIER___ ()

@property (nonatomic, strong) <#requestClass#> *request;

@property (nonatomic, strong) NSAddressNoDataView *noDataView;

@end

@implementation ___FILEBASENAMEASIDENTIFIER___

- (void)dealloc {
    DLog(@"");
}

//static Views without use nib
- (void)loadView {
    [super loadView];
    
    [self staticViewsWithoutNib];
}

#pragma mark - 界面加载
- (void)staticViewsWithoutNib{
    
    self.title = <#titleString#>;
    
    self.noDataView.frame = CGRectMake(0, self.navBar.bottom, self.view.width, self.view.height - self.navBar.bottom);
    [self.view addSubview:self.noDataView];
    [self.noDataView setHidden:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do view setup here.ref:NSGoodShopAroundController
    
    if ([[Reachability reachabilityForInternetConnection] currentReachabilityStatus] == NotReachable) {
        // 无网络，空页面，网络异常，请检查您的网络连接
        [self showNodataViewWithErrorMsg:@"网络异常，请检查您的网络连接"];
    }else{
        [self loadData];
    }
}

/**
 加载数据
 */
- (void)loadData;{
    
    @weakify(self);
    [self displayOverFlowActivityView];
    [self.request layoutRequestBackData:^(BOOL isSuccess,NSString *errorMsg) {
        @strongify(self);
        [self removeOverFlowActivityView];
        if (isSuccess) {
            
//            if (!self.request.dataArray.count) {
//                [self showNodataViewWithErrorMsg:@"暂无数据"];
//                return;
//            }
            //success + have data
            [self hideNodataView];
            
            //布局
            
        } else {
            [SNToast toast:errorMsg];
            if (!self.request.dataArray.count) {
                [self showNodataViewWithErrorMsg:errorMsg];
            }
        }
    }];
}
#pragma mark - Change Values

#pragma mark - nodataView
-(void)showNodataViewWithErrorMsg:(NSString *)errorMsg{
    if (self.noDataView.isHidden) {
        [self.noDataView setHidden:NO];
    }
    self.noDataView.tipsOneLabel.text = SafeString(errorMsg);
    if ([errorMsg isEqualToString:@"暂无数据"]) {
        self.noDataView.TipsNewWorkButton.hidden = YES;
    }else {
        self.noDataView.TipsNewWorkButton.hidden = NO;
    }
}

-(void)hideNodataView{
    if (!self.noDataView.isHidden) {
        [self.noDataView setHidden:YES];
    }
}

#pragma mark - Delegate


#pragma mark - Lazy load
- (<#requestClass#> *)request{
    if (!_request) {
        _request=[[<#requestClass#> alloc]init];
    }
    return _request;
}

-(NSAddressNoDataView *)noDataView{
    if (!_noDataView) {
        _noDataView = [[NSAddressNoDataView alloc]init];
        [_noDataView refreshLayoutSubview:ADDRESS_NODATA_NETWORK];
        @weakify(self);
        [_noDataView setAddressNodataReloadBlock:^(ADDRESS_NODATA_STATUS status) {
            @strongify(self);
            if ([[Reachability reachabilityForInternetConnection] currentReachabilityStatus] == NotReachable) {
                // 无网络，空页面，网络异常，请检查您的网络连接
                [self showNodataViewWithErrorMsg:@"网络异常，请检查您的网络连接"];
            } else {
                [self loadData];
            }
        }];
        [_noDataView setAddressGotoNetworkHelpBlock:^{
            @strongify(self);
            Class nHelpClass =  NSClassFromString(@"NSNetworkHelpViewController");
            if (nHelpClass && self.navigationController) {
                UIViewController *nHelp = [[nHelpClass alloc]init];
                [self.navigationController pushViewController:nHelp animated:YES];
            }
        }];
    }
    return _noDataView;
}

@end
