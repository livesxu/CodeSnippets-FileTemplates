//___FILEHEADER___

#import "___FILEBASENAME___.h"

@implementation ___FILEBASENAMEASIDENTIFIER___

- (NSString *)description {
    
    NSMutableString *mutStr = [NSMutableString string];
    unsigned int outCount = 0;
    objc_property_t *properties = class_copyPropertyList([self class], &outCount);
    for (int i = 0; i < outCount; i++) {
        objc_property_t property = properties[i];
        NSString *name = @(property_getName(property));
        NSString *value = [self valueForKeyPath:name];
        [mutStr appendFormat:@"%@:%@;", name, value];
    }
    return mutStr;
}
////yyModel
////字段映射
//+ (nullable NSDictionary<NSString *, id> *)modelCustomPropertyMapper{
//    return @{
//             @"<#key#>":@"<#map#>",
//             };//key 映射 map  eg: id_stand:id
//}
////集合类映射
//+ (nullable NSDictionary<NSString *, id> *)modelContainerPropertyGenericClass{
//    return @{
//             @"<#key#>" : [<#mapClass#> class],
//             };//key字段子集类映射  eg: usersArray:UserInfo
//}

@end
